var formula = `{
    "conversions": [
        {
            "from": "Celsius",
            "to": "Fahrenheit",
            "formula": "F = C(9/5) + 32"
        },
        {
            "from": "Fahrenheit",
            "to": "Celsius",
            "formula": "C = (F - 32) * 5/9"
        }
    ]
}`;